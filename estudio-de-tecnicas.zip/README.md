# Final-Degree-Project---Slides
Slides for the presentation of my Final Degree Project.  It was a requirement to make it in spanish, so I apologize for that.

## INFO
Project code and documentation will be uploaded and then linked here. 

## THOUGHTS
Please let me know if you want to share any information or discuss a topic!
